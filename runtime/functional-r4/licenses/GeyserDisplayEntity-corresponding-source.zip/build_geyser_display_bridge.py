#!/usr/bin/env python3
"""Build a separate pinned AGPL display extension; never alter the core plugin.

Reads a clean public upstream checkout and an already verified Geyser Spigot JAR.
No dependency downloads, upstream Gradle execution, server writes or network calls.
The resulting archive includes corresponding modified source and the AGPL license.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

PIN = "3d22bff3265f85812beaeb5e3b7e898ee4a58105"
VERSION = "1.0.14-gtm-b1308-r1"
PACKAGE = Path("src/main/java/me/geyserextensionists/geyserdisplayentity")


def replace(text, before, after):
    if text.count(before) != 1:
        raise ValueError("Pinned patch does not match exactly: " + before[:70])
    return text.replace(before, after)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build(source, geyser, java_home, output, compile_only):
    source, geyser, java_home, output = map(lambda p: Path(p).resolve(), (source, geyser, java_home, output))
    revision = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
    if revision != PIN:
        raise ValueError("The public source checkout must match the reviewed commit")
    subprocess.run(["git", "-C", str(source), "diff", "--exit-code", "HEAD", "--", "src", "LICENSE"], check=True, stdout=subprocess.DEVNULL)
    output.mkdir(parents=True, exist_ok=True)
    patched = output / "corresponding-source"
    shutil.copytree(source / "src", patched / "src", dirs_exist_ok=True)
    shutil.copy2(source / "LICENSE", patched / "LICENSE")
    shutil.copy2(__file__, patched / "build_geyser_display_bridge.py")
    changes = []
    for path in (patched / "src/main/java").rglob("*.java"):
        old = path.read_text()
        new = old.replace("import org.spongepowered.configurate.", "import org.geysermc.geyser.platform.spigot.shaded.org.spongepowered.configurate.")
        if path.name == "SlotDisplayEntity.java":
            # Original exports used ten units per block; Bedrock model units are16.
            new = new.replace("translation.getX() * 10", "-translation.getX() * 16").replace("translation.getY() * 10", "translation.getY() * 16").replace("translation.getZ() * 10", "translation.getZ() * 16")
            new = new.replace("t.getX() * 10", "-t.getX() * 16").replace("t.getY() * 10", "t.getY() * 16").replace("t.getZ() * 10", "t.getZ() * 16")
            start = new.index("    protected void pushRotationProperties() {")
            end = new.index("\n    public void setScale", start)
            new = new[:start] + '''    protected void pushRotationProperties() {
        // Keep the two rotations on opposite sides of scale, including nonuniform scale.
        // Geyser may initialize metadata from the superclass constructor.
        Vector3f left = toEulerZYX(lastLeft == null ? Quaternionf.IDENTITY : lastLeft).add(displayRotation);
        Vector3f right = toEulerZYX(lastRight == null ? Quaternionf.IDENTITY : lastRight);
        pushEuler("r", left);
        pushEuler("rr", right);
    }

    private void pushEuler(String prefix, Vector3f value) {
        propertyManager.addProperty(new FloatProperty(Identifier.of("geyser:" + prefix + "_x"), 180F, -180F, 0F), MathUtils.wrapDegrees(value.getX()));
        propertyManager.addProperty(new FloatProperty(Identifier.of("geyser:" + prefix + "_y"), 180F, -180F, 0F), MathUtils.wrapDegrees(-value.getY()));
        propertyManager.addProperty(new FloatProperty(Identifier.of("geyser:" + prefix + "_z"), 180F, -180F, 0F), MathUtils.wrapDegrees(-value.getZ()));
    }
''' + new[end:]
            new = new.replace("            setRotation(quaternion);\n            rotationUpdated = true;\n            applyBedrockYawPitchFromCombined();", "            pushRotationProperties();\n            rotationUpdated = true;\n            updateBedrockEntityProperties();")
        if path.name == "ItemDisplayEntity.java":
            start = new.index("    @Override\n    public Vector3f bedrockRotation() {")
            end = new.index("\n    }", start) + len("\n    }")
            new = new[:start] + '''    @Override
    public Vector3f bedrockRotation() {
        // Display rotations are applied once by the attached model hierarchy.
        return Vector3f.from(getPitch(), getYaw(), getYaw());
    }''' + new[end:]
        if path.name == "GeyserDisplayEntity.java":
            new = replace(new, '        BLOCK_DISPLAY_BEDROCK = EntityUtils.findOrRegisterCustomDefinition(this, event, Identifier.of("geyser:block_display"));\n', "")
            new = replace(new, '            registerDisplayProperties(event, Identifier.of("geyser:block_display"));\n', "")
            start = new.index("            BLOCK_DISPLAY = VanillaEntityType.inherited")
            end = new.index("            ITEM_DISPLAY =", start)
            new = new[:start] + new[end:]
        if new != old:
            path.write_text(new)
            changes.append({"path": str(path.relative_to(patched)), "upstream_sha256": hashlib.sha256(old.encode()).hexdigest(), "modified_sha256": sha(path)})
    config = patched / "src/main/resources/Extension/config.yml"
    config.write_text("general:\n  height: 0.0\n  y-offset: 0.0\n  vanilla-scale: false\n  vanilla-scale-multiplier: 1.0\n  hand: false\nhide-types: []\nhide-custom-types: []\nhide-unmapped-vanilla-displays: true\nsettings:\n  debug:\n    per-player-load-mappings: false\n    log-displays: false\n")
    properties = patched / "src/main/resources/Extension/Entities/item-displays.yml"
    text = properties.read_text()
    for axis in "xyz":
        text += f'    rr-{axis}:\n      id: "geyser:rr_{axis}"\n      property-type: "float"\n      min-value: -180\n      max-value: 180\n      default-value: 0.0\n'
    properties.write_text(text)
    classes = output / "classes"
    if classes.exists():
        shutil.rmtree(classes)
    classes.mkdir()
    classpath = [geyser, *map(lambda p: Path(p).resolve(), compile_only)]
    command = [str(java_home / "bin/javac"), "--release", "21", "-encoding", "UTF-8", "-cp", ":".join(map(str, classpath)), "-d", str(classes),
               *map(str, sorted((patched / "src/main/java").rglob("*.java")))]
    result = subprocess.run(command, capture_output=True, text=True)
    (output / "compile.log").write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError("Display bridge compilation failed; see compile.log")
    for path in (patched / "src/main/resources").rglob("*"):
        if path.is_file():
            destination = classes / path.relative_to(patched / "src/main/resources")
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(path.read_bytes().replace(b"${version}", VERSION.encode()) if path.name == "extension.yml" else path.read_bytes())
    shutil.copy2(patched / "LICENSE", classes / "LICENSE-GeyserDisplayEntity.txt")
    report = {"upstream_url": "https://github.com/GeyserExtensionists/GeyserDisplayEntity", "upstream_commit": PIN,
              "version": VERSION, "license": "AGPL-3.0", "geyser_sha256": sha(geyser), "compile_exit": 0,
              "compile_only_libraries": [{"file": p.name, "sha256": sha(p)} for p in classpath[1:]],
              "source_modifications": changes, "changes": ["Exact Spigot-bundled Configurate imports", "16-unit model translation with mirrored X", "Separate left and right quaternion rotations around scale", "No duplicate entity quaternion rotation", "ItemDisplay only; unrelated BlockDisplay mapping is untouched"],
              "native_client_validation": "not_run"}
    (patched / "BUILD_PROVENANCE.json").write_text(json.dumps(report, indent=2) + "\n")
    (patched / "README.txt").write_text("Modified GeyserDisplayEntity for the pinned Geyser Spigot build1308.\nLicense: GNU AGPLv3; see LICENSE. This is a separate extension, not core plugin code.\nThe supplied src tree is the complete modified source used for the included binary.\nCompile src/main/java with Java21+ against the pinned Geyser Spigot JAR, Guava and Checker Qualifier;\ncopy src/main/resources to the output, replace ${version} in extension.yml with " + VERSION + ", and jar the result.\nThe included builder reproducibly patches the separately provided clean upstream checkout at the pinned commit.\nThe matching GTM Bedrock pack supplies the display geometry and exact item mappings.\nServer boot and native-client render verification are separate acceptance gates.\n")
    for destination, directory in ((output / f"GeyserDisplayEntity-{VERSION}.jar", classes), (output / f"GeyserDisplayEntity-{VERSION}-source.zip", patched)):
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(directory.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(directory))
    (output / "build-report.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for name in ("source", "geyser", "java-home", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--compile-only", action="append", default=[])
    args = parser.parse_args()
    report = build(args.source, args.geyser, args.java_home, args.output, args.compile_only)
    print(json.dumps({key: report[key] for key in ("version", "compile_exit", "geyser_sha256", "native_client_validation")}, indent=2))
