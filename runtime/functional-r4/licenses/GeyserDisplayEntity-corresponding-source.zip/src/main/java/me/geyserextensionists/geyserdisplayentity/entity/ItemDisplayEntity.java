package me.geyserextensionists.geyserdisplayentity.entity;

import me.geyserextensionists.geyserdisplayentity.GeyserDisplayEntity;
import me.geyserextensionists.geyserdisplayentity.managers.ConfigManager;
import me.geyserextensionists.geyserdisplayentity.type.DisplayType;
import me.geyserextensionists.geyserdisplayentity.util.DeltaUtils;
import me.geyserextensionists.geyserdisplayentity.util.FileConfiguration;
import org.cloudburstmc.math.imaginary.Quaternionf;
import org.cloudburstmc.math.vector.Vector3f;
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes;
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId;
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData;
import org.cloudburstmc.protocol.bedrock.packet.MobArmorEquipmentPacket;
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket;
import org.cloudburstmc.protocol.bedrock.packet.MoveEntityAbsolutePacket;
import org.geysermc.geyser.entity.spawn.EntitySpawnContext;
import org.geysermc.geyser.entity.type.Tickable;
import org.geysermc.geyser.entity.vehicle.ClientVehicle;
import org.geysermc.geyser.item.Items;
import org.geysermc.geyser.session.GeyserSession;
import org.geysermc.geyser.skin.SkinManager;
import org.geysermc.geyser.translator.item.ItemTranslator;
import org.geysermc.geyser.util.MathUtils;
import org.geysermc.mcprotocollib.auth.texture.Texture;
import org.geysermc.mcprotocollib.auth.texture.TextureType;
import org.geysermc.mcprotocollib.protocol.data.game.entity.metadata.EntityMetadata;
import org.geysermc.mcprotocollib.protocol.data.game.entity.metadata.type.ByteEntityMetadata;
import org.geysermc.mcprotocollib.protocol.data.game.entity.player.ResolvableProfile;
import org.geysermc.mcprotocollib.protocol.data.game.item.ItemStack;
import org.geysermc.mcprotocollib.protocol.data.game.item.component.CustomModelData;
import org.geysermc.mcprotocollib.protocol.data.game.item.component.DataComponentTypes;
import org.geysermc.mcprotocollib.protocol.data.game.item.component.DataComponents;

import java.util.Arrays;
import java.util.List;

public class ItemDisplayEntity extends SlotDisplayEntity implements Tickable {

    // Steve, which Java draws when a profile has no skin
    private static final String DEFAULT_SKIN = "http://textures.minecraft.net/texture/31f477eb1a7beee631c2ca64d06f8f68fa93a3386d04452ab27f43acdf1b60cb";
    // Where Java draws a player_head in an item display: an 8 px cube whose bottom is half a block below the origin
    private static final float HEAD_CENTRE_Y = -0.25f;

    private DisplayType displayType = DisplayType.NONE;
    private Byte color;
    private boolean custom = false;
    private boolean needHide = false;

    private ResolvableProfile headProfile;
    private String headSkin;
    private DisplayHeadEntity head;
    private Vector3f headPlacedAt;
    private float headFacing;

    public ItemDisplayEntity(EntitySpawnContext entitySpawnContext) {
        super(entitySpawnContext);
    }

    @Override
    public void spawnEntity() {
        super.spawnEntity();
        moveAbsoluteRaw(position, yaw, pitch, headYaw, onGround, true);
        spawnHead();
    }

    @Override
    public void despawnEntity() {
        if (head != null) {
            head.despawnEntity();
            head = null;
        }
        super.despawnEntity();
    }

    @Override
    public void tick() {
        if (head != null) placeHead();
    }

    @Override
    public Vector3f bedrockPosition() {
        if (config == null) return super.bedrockPosition();
        return super.bedrockPosition().up((float) config.getDouble("y-offset"));
    }

    public void setDisplayedItem(EntityMetadata<ItemStack, ?> entityMetadata) {
        ItemStack stack = entityMetadata.getValue();
        if (stack == null) {
            this.item = ItemData.AIR;
            setInvisible(true);
            removeHead();
            return;
        }

        DataComponents components = stack.getDataComponentsPatch();
        ResolvableProfile profile = stack.getId() == Items.PLAYER_HEAD.javaId() && components != null
                ? components.get(DataComponentTypes.PROFILE) : null;
        if (profile != null) {
            showHead(profile);
            this.item = ItemData.AIR;
            updateMainHand(session);
            return;
        }
        removeHead();

        config = GeyserDisplayEntity.getExtension().getConfigManager().getGeneralConfig();

        ItemData item = ItemTranslator.translateToBedrock(session, stack);
        this.item = item;

        // Read the dye straight from the components: Geyser's internal item classes
        // (DyeableArmorItem, DyeItem, ...) get renamed between builds and break the extension
        this.color = null;
        DataComponents data = stack.getDataComponentsPatch();
        if (data != null) {
            Integer dyed = data.get(DataComponentTypes.DYED_COLOR);
            if (dyed != null) {
                this.color = Byte.parseByte(String.valueOf(getColor(dyed)));
            }
        }

        String type = session.getItemMappings().getMapping(stack.getId()).getJavaItem().javaIdentifier().toString();

        boolean mappingApplied = false;
        for (FileConfiguration mappingsConfig : GeyserDisplayEntity.getExtension().getConfigManager().getConfigMappingsCache().values()) {
            if (mappingsConfig == null) continue;

            for (Object mappingKey : mappingsConfig.getRootNode().childrenMap().keySet()) {
                String mappingString = mappingKey.toString();

                FileConfiguration mappingConfig = mappingsConfig.getConfigurationSection(mappingString);
                if (mappingConfig == null) continue;
                if (!mappingConfig.getString("type").equals(type)) continue;

                boolean applied;
                if (mappingConfig.contains("model-data")) {
                    applied = applyLegacyModelData(stack, mappingConfig);
                } else {
                    applied = applyModernItemModels(item, mappingConfig);
                }

                if (applied) {
                    mappingApplied = true;
                    if (GeyserDisplayEntity.getExtension().getConfigManager().getConfig().getBoolean("settings.debug.per-player-load-mappings")) GeyserDisplayEntity.getExtension().logger().info("Loading Mappings: " + mappingString + " - " + mappingConfig.getString("item-identifier"));
                    break;
                }
            }

            if (mappingApplied) break;
        }

        if (!item.getDefinition().getIdentifier().startsWith("minecraft:")) {
            custom = true;
            if (color != null) {
                getMetadata().put(EntityDataTypes.COLOR, color);
            }
        } else {
            custom = false;
        }

        // HIDE_TYPES check only if stack is present (it is)
        String javaID = session.getItemMappings().getMapping(stack).getJavaItem().javaIdentifier().toString();
        boolean wasHiddenByType = needHide;

        ConfigManager cfg = GeyserDisplayEntity.getExtension().getConfigManager();
        boolean hiddenByType = cfg.getHideTypes().contains(javaID);
        boolean forceHiddenCustomType = cfg.getHideCustomTypes().contains(javaID);
        boolean unmappedVanilla = cfg.isHideUnmappedVanilla() && !custom && !mappingApplied;

        boolean hidden = (hiddenByType && !custom) || forceHiddenCustomType || unmappedVanilla;

        if (cfg.isLogDisplays()) {
            GeyserDisplayEntity.getExtension().logger().info("ItemDisplay java=" + javaID
                    + " bedrock=" + item.getDefinition().getIdentifier()
                    + " custom=" + custom + " mapped=" + mappingApplied
                    + " -> " + (hidden ? "HIDDEN" : "SHOWN"));
        }

        if (hidden) {
            setInvisible(true);
            needHide = true;
            this.metadata.put(EntityDataTypes.SCALE, 0f);
        } else {
            needHide = false;
            if (wasHiddenByType) {
                setInvisible(false);

                if (config != null && config.getBoolean("vanilla-scale")) {
                    applyScale();
                } else {
                    this.metadata.put(EntityDataTypes.SCALE, 1f);
                }
            }
        }

        updateMainHand(session);
    }

    private void showHead(ResolvableProfile profile) {
        if (profile.equals(headProfile)) return;

        headProfile = profile;
        SkinManager.resolveProfile(profile).whenComplete((resolved, error) -> session.ensureInEventLoop(() -> {
            if (headProfile != profile) return;
            Texture texture = resolved == null ? null : SkinManager.getTextureDataFromProfile(resolved, TextureType.SKIN);
            headSkin = texture == null ? DEFAULT_SKIN : texture.getURL();
            spawnHead();
        }));
    }

    private void spawnHead() {
        if (!valid || headSkin == null) return;

        if (head == null) {
            head = new DisplayHeadEntity(session);
            head.spawnEntity();
            headPlacedAt = null;
        }
        head.setSkin(headSkin);
        placeHead();
    }

    private void removeHead() {
        headProfile = null;
        headSkin = null;
        if (head != null) {
            head.despawnEntity();
            head = null;
        }
    }

    /**
     * Lays the head out as Java does: the display's transformation (translation, left rotation, scale, right rotation)
     * applied to the head, inside the display's frame, which billboarding turns to the viewer. Bedrock cannot tilt a
     * player entity, so the frame only turns about the vertical axis and the head always stands upright.
     */
    private void placeHead() {
        Quaternionf left = Quaternionf.from(lastLeft).normalize();
        Quaternionf right = Quaternionf.from(lastRight).normalize();

        Vector3f inner = right.rotate(0, HEAD_CENTRE_Y, 0).mul(scale);
        Vector3f centre = left.rotate(inner.getX(), inner.getY(), inner.getZ()).add(translation);

        float frameYaw;
        if (billboard == BILLBOARD_VERTICAL || billboard == BILLBOARD_CENTER) {
            Vector3f toViewer = session.getPlayerEntity().position().sub(position);
            frameYaw = (float) Math.toDegrees(Math.atan2(-toViewer.getX(), toViewer.getZ()));
        } else {
            frameYaw = getYaw();
        }
        double radians = Math.toRadians(frameYaw);
        float sin = (float) Math.sin(radians);
        float cos = (float) Math.cos(radians);
        Vector3f world = position.add(centre.getX() * cos - centre.getZ() * sin, centre.getY(), centre.getX() * sin + centre.getZ() * cos);

        // The face is on the display's -Z: the item model turns the skull over (180 about X) and the item display
        // turns every item about Y, so a FIXED head looks away from its yaw and a billboarded one away from the viewer
        Vector3f facing = left.mul(right).rotate(0, 0, -1);
        float yaw = MathUtils.wrapDegrees(frameYaw + (float) Math.toDegrees(Math.atan2(-facing.getX(), facing.getZ())));
        float size = (scale.getX() + scale.getY() + scale.getZ()) / 3;
        Vector3f origin = world.up(HEAD_CENTRE_Y * size);

        boolean first = headPlacedAt == null;
        if (first || origin.distanceSquared(headPlacedAt) > 1.0E-6f || Math.abs(MathUtils.wrapDegrees(yaw - headFacing)) > 0.5f) {
            headPlacedAt = origin;
            headFacing = yaw;
            head.place(origin, yaw, size, first);
        }
    }

    private boolean applyLegacyModelData(ItemStack item, FileConfiguration mappingConfig) {
        CustomModelData modelData = null;
        DataComponents components = item.getDataComponentsPatch();

        if (components != null) modelData = components.get(DataComponentTypes.CUSTOM_MODEL_DATA);
        if (mappingConfig.getInt("model-data") == -1) return entityApplyDisplayConfig(mappingConfig);
        if (modelData == null) return false;
        
        if (Math.abs(mappingConfig.getInt("model-data") - modelData.floats().get(0)) < 0.5) return entityApplyDisplayConfig(mappingConfig);

        return false;
    }

    private boolean applyModernItemModels(ItemData itemData, FileConfiguration mappingConfig) {
        String itemBedrockIdentifier = itemData.getDefinition().getIdentifier().replace("geyser_custom:", "");
        String mappingIdentifier = mappingConfig.getString("item-identifier");

        if (mappingIdentifier.equalsIgnoreCase("none")) return entityApplyDisplayConfig(mappingConfig);
        if (mappingIdentifier.equalsIgnoreCase(itemBedrockIdentifier)) return entityApplyDisplayConfig(mappingConfig);

        return false;
    }

    private boolean entityApplyDisplayConfig(FileConfiguration mappingConfig) {
        FileConfiguration mappingOptions = mappingConfig.getConfigurationSection("displayentityoptions");
        if (mappingOptions == null) {
            // Legacy compatibility for pre-migration config.yml format
            mappingOptions = mappingConfig.getConfigurationSection("options");
        }

        if (mappingOptions != null) {
            config = mappingOptions;
        } else if (config == null) {
            return false;
        }

        if (config.getBoolean("vanilla-scale")) applyScale();
        applyMappingDisplayTransform(config);

        if (valid) {
            moveAbsoluteRaw(position, yaw, pitch, headYaw, onGround, true);
        }
        return true;
    }

    private void applyMappingDisplayTransform(FileConfiguration cfg) {
        Vector3f rot = readVec3(cfg, "rotation");
        Vector3f trans = readVec3(cfg, "translation");
        if (rot == null && trans == null) return;
        applyMappingTransform(
                rot != null ? rot : Vector3f.from(0, 0, 0),
                trans != null ? trans : Vector3f.from(0, 0, 0));
    }

    private static Vector3f readVec3(FileConfiguration cfg, String key) {
        if (cfg == null || !cfg.contains(key)) return null;
        List<Float> v = cfg.getFloatList(key);
        if (v.size() < 3) return null;
        return Vector3f.from(v.get(0), v.get(1), v.get(2));
    }

    @Override
    protected void applyScale() {
        if (needHide) {
            metadata.put(EntityDataTypes.SCALE, 0f);
        } else {
            super.applyScale();
        }
    }

    @Override
    public void updateMainHand(GeyserSession session) {
        if (!valid) return;

        ItemData helmet = ItemData.AIR; // TODO
        ItemData chest = item;

        if (custom && (config == null || !config.getBoolean("hand"))) {
            MobArmorEquipmentPacket armorEquipmentPacket = new MobArmorEquipmentPacket();
            armorEquipmentPacket.setRuntimeEntityId(geyserId);
            armorEquipmentPacket.setHelmet(helmet);
            armorEquipmentPacket.setBoots(ItemData.AIR);
            armorEquipmentPacket.setChestplate(chest);
            armorEquipmentPacket.setLeggings(ItemData.AIR);
            armorEquipmentPacket.setBody(ItemData.AIR);

            session.sendUpstreamPacket(armorEquipmentPacket);
        } else {
            MobEquipmentPacket handPacket = new MobEquipmentPacket();
            handPacket.setRuntimeEntityId(geyserId);
            handPacket.setItem(item);
            handPacket.setHotbarSlot(-1);
            handPacket.setInventorySlot(0);
            handPacket.setContainerId(ContainerId.INVENTORY);

            session.sendUpstreamPacket(handPacket);
        }
    }

    public void setDisplayType(ByteEntityMetadata entityMetadata) {
        int i = entityMetadata.getPrimitiveValue();
        displayType = DisplayType.values()[i];
    }

    private static int getColor(int argb) {
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;

        double[] colorLab = DeltaUtils.rgbToLab(r, g, b);

        List<int[]> colors = Arrays.asList(
                new int[]{249, 255, 254},    // 0: White
                new int[]{249, 128, 29},     // 1: Orange
                new int[]{199, 78, 189},     // 2: Magenta
                new int[]{58, 179, 218},     // 3: Light Blue
                new int[]{254, 216, 61},     // 4: Yellow
                new int[]{128, 199, 31},     // 5: Lime
                new int[]{243, 139, 170},    // 6: Pink
                new int[]{71, 79, 82},       // 7: Gray
                new int[]{159, 157, 151},    // 8: Light Gray
                new int[]{22, 156, 156},     // 9: Cyan
                new int[]{137, 50, 184},     // 10: Purple
                new int[]{60, 68, 170},      // 11: Blue
                new int[]{131, 84, 50},      // 12: Brown
                new int[]{94, 124, 22},      // 13: Green
                new int[]{176, 46, 38},      // 14: Red
                new int[]{29, 29, 33}        // 15: Black
        );

        int closestColorIndex = -1;
        double minDeltaE = Double.MAX_VALUE;

        for (int i = 0; i < colors.size(); i++) {
            int[] rgb = colors.get(i);
            double[] lab = DeltaUtils.rgbToLab(rgb[0], rgb[1], rgb[2]);
            double deltaE = DeltaUtils.calculateDeltaE(colorLab, lab);
            if (deltaE < minDeltaE) {
                minDeltaE = deltaE;
                closestColorIndex = i;
            }
        }

        return closestColorIndex;
    }

    @Override
    public void moveAbsoluteRaw(Vector3f position, float yaw, float pitch, float headYaw, boolean isOnGround, boolean teleported) {
        setPosition(position);
        setYaw(yaw);
        setPitch(pitch);
        setHeadYaw(headYaw);
        setOnGround(isOnGround);

        MoveEntityAbsolutePacket moveEntityPacket = new MoveEntityAbsolutePacket();
        moveEntityPacket.setRuntimeEntityId(geyserId);
        moveEntityPacket.setPosition(bedrockPosition());
        moveEntityPacket.setRotation(bedrockRotation());
        moveEntityPacket.setOnGround(isOnGround);
        moveEntityPacket.setTeleported(teleported);

        session.sendUpstreamPacket(moveEntityPacket);
    }

    @Override
    public void moveRelativeRaw(double relX, double relY, double relZ, float yaw, float pitch, float headYaw, boolean isOnGround) {
        if (this instanceof ClientVehicle clientVehicle) {
            if (clientVehicle.shouldSimulateMovement()) return;

            clientVehicle.getVehicleComponent().moveRelative(relX, relY, relZ);
        }

        this.position = Vector3f.from(this.position.getX() + relX, this.position.getY() + relY, this.position.getZ() + relZ);
        setOnGround(isOnGround);

        if (pitch != this.pitch) {
            this.pitch = pitch;
        }

        if (yaw != this.yaw) {
            this.yaw = yaw;
        }

        if (headYaw != this.headYaw) {
            this.headYaw = headYaw;
        }

        moveAbsoluteRaw(this.position, this.yaw, this.pitch, this.headYaw, isOnGround, false);
    }

    @Override
    public Vector3f bedrockRotation() {
        // Display rotations are applied once by the attached model hierarchy.
        return Vector3f.from(getPitch(), getYaw(), getYaw());
    }
}
