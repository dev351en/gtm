Modified GeyserDisplayEntity for the pinned Geyser Spigot build1308.
License: GNU AGPLv3; see LICENSE. This is a separate extension, not core plugin code.
The supplied src tree is the complete modified source used for the included binary.
Compile src/main/java with Java21+ against the pinned Geyser Spigot JAR, Guava and Checker Qualifier;
copy src/main/resources to the output, replace ${version} in extension.yml with 1.0.14-gtm-b1308-r1, and jar the result.
The included builder reproducibly patches the separately provided clean upstream checkout at the pinned commit.
The matching GTM Bedrock pack supplies the display geometry and exact item mappings.
Server boot and native-client render verification are separate acceptance gates.
