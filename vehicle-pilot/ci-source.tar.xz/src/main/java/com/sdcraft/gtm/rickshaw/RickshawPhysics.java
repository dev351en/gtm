package com.sdcraft.gtm.rickshaw;

/**
 * Deterministic per-tick motion; no Paper calls, no client mod and no native memory.
 * All positions are server authoritative. Units: blocks/tick, degrees and blocks.
 */
public final class RickshawPhysics {
    public static final double MAX_FORWARD = 0.22;  // ~4.4 blocks/second
    public static final double MAX_REVERSE = -0.08;

    public record Input(boolean forward, boolean backward, boolean left, boolean right) {}
    public record State(double speed, double yaw, double x, double z) {}

    private RickshawPhysics() {}

    public static State step(State previous, Input input) {
        double speed = previous.speed;
        if (input.forward && !input.backward) {
            speed = Math.min(MAX_FORWARD, speed + 0.009);
        } else if (input.backward && !input.forward) {
            if (speed > 0.015) {
                speed *= 0.77; // braking before attempting reverse
            } else {
                speed = Math.max(MAX_REVERSE, speed - 0.005);
            }
        } else {
            speed *= 0.945;  // rolling resistance
        }
        if (Math.abs(speed) < 0.001) speed = 0;
        double steer = (input.left ? 1 : 0) - (input.right ? 1 : 0);
        double steeringPower = Math.min(1.0, Math.abs(speed) / 0.1);
        double yaw = previous.yaw + steer * steeringPower * 2.7 * Math.signum(speed);
        double rad = Math.toRadians(yaw);
        return new State(speed, yaw,
                previous.x - Math.sin(rad) * speed,
                previous.z + Math.cos(rad) * speed);
    }

    public static double offsetX(double localX, double localZ, double yaw) {
        double rad = Math.toRadians(yaw);
        return Math.cos(rad) * localX - Math.sin(rad) * localZ;
    }

    public static double offsetZ(double localX, double localZ, double yaw) {
        double rad = Math.toRadians(yaw);
        return Math.sin(rad) * localX + Math.cos(rad) * localZ;
    }
}
