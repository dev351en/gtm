package com.sdcraft.gtm.rickshaw;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.bukkit.Bukkit;
import org.bukkit.Input;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import org.bukkit.util.Transformation;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

/**
 * One real modelled auto-rickshaw, no mandatory client mod.
 *
 * Paper 26.3 controls come from Player.getCurrentInput() (works with the
 * normal Java protocol, including FoldCraft's mapped WASD). Its six entities
 * are one 123-part ItemDisplay, four invisible seat anchors and one clickable
 * Interaction. All motion/permissions live on the server. No world edits.
 *
 * This is a performance-bounded flat-road pilot, not a finished vehicle fleet:
 * no persistence, fuel, damage, traffic AI or stair-climbing simulation yet.
 */
public final class GtmRickshawPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private NamespacedKey modelId;
    private NamespacedKey tokenModelId;
    private NamespacedKey tokenKey;
    private NamespacedKey vehicleKey;
    private final Map<UUID, Rickshaw> rickshaws = new LinkedHashMap<>();
    private BukkitTask ticker;
    private int maxVehicles;
    private int ticks;

    private static final double[][] SEAT_OFFSETS = {
        { 0.00, 0.54, 0.42 },  // driver, front center
        {-0.43, 0.59,-0.49 },  // rear left
        { 0.00, 0.59,-0.49 },  // rear center
        { 0.43, 0.59,-0.49 }   // rear right
    };
    private static final double[][] COLLISION_POINTS = {
        { 0.00, 0.00 }, { 0.58, 1.12 }, {-0.58, 1.12 },
        { 0.58,-0.88 }, {-0.58,-0.88 }, { 0.0,1.15 }, { 0.0,-0.88 }
    };

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxVehicles = Math.max(1, Math.min(12, getConfig().getInt("max-rickshaws", 6)));
        modelId = NamespacedKey.fromString("gtm_vehicle:mumbai_auto");
        tokenModelId = NamespacedKey.fromString("gtm_vehicle:auto_token");
        tokenKey = new NamespacedKey(this, "spawn_token");
        vehicleKey = new NamespacedKey(this, "rickshaw_id");
        PluginCommand cmd = getCommand("gtmrickshaw");
        if (cmd == null) throw new IllegalStateException("gtmrickshaw command missing from plugin.yml");
        cmd.setExecutor(this);
        cmd.setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        ticker = Bukkit.getScheduler().runTaskTimer(this, this::tick, 1L, 1L);
        getLogger().info("Rickshaw pilot ready: 1 model display + 4 seats + 1 hitbox per auto, max "
                + maxVehicles + ". Load the matching GTM Java resource pack first.");
    }

    @Override
    public void onDisable() {
        if (ticker != null) ticker.cancel();
        for (Rickshaw v : new ArrayList<>(rickshaws.values())) remove(v);
        rickshaws.clear();
    }

    private ItemStack modelItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        item.editMeta(meta -> meta.setItemModel(modelId));
        return item;
    }

    private ItemStack tokenItem() {
        ItemStack item = new ItemStack(Material.PAPER);
        item.editMeta(meta -> {
            meta.setItemModel(tokenModelId);
            meta.displayName(Component.text("GTM Mumbai Auto-Rickshaw", NamedTextColor.GOLD));
            meta.getPersistentDataContainer().set(tokenKey, PersistentDataType.BYTE, (byte) 1);
        });
        return item;
    }

    private boolean isToken(ItemStack item) {
        return item != null && item.hasItemMeta()
            && item.getItemMeta().getPersistentDataContainer().has(tokenKey, PersistentDataType.BYTE);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This pilot is operated in-game as a player.");
            return true;
        }
        String action = args.length == 0 ? "help" : args[0].toLowerCase(java.util.Locale.ROOT);
        if (action.equals("spawn") || action.equals("give") || action.equals("remove")) {
            if (!player.hasPermission("gtmrickshaw.admin")) {
                player.sendMessage("You need gtmrickshaw.admin for vehicle administration.");
                return true;
            }
        }
        switch (action) {
            case "spawn" -> spawnFor(player);
            case "give" -> {
                Map<Integer, ItemStack> unaccepted = player.getInventory().addItem(tokenItem());
                if (unaccepted.isEmpty()) player.sendMessage("Given one GTM spawn token; right-click to place an auto.");
                else player.sendMessage("Free one inventory slot first.");
            }
            case "remove" -> {
                Rickshaw nearest = nearest(player.getLocation(), 7);
                if (nearest == null) player.sendMessage("No GTM pilot auto found within seven blocks.");
                else { remove(nearest); rickshaws.remove(nearest.id); player.sendMessage("Pilot auto removed."); }
            }
            case "status" -> {
                Rickshaw nearest = nearest(player.getLocation(), 10);
                if (nearest == null) player.sendMessage("No nearby auto. Active: " + rickshaws.size() + "/" + maxVehicles);
                else player.sendMessage("Auto " + nearest.id.toString().substring(0, 8) + ": "
                    + Math.round(Math.abs(nearest.speed) * 72) + " km/h (game scale), "
                    + occupied(nearest) + "/4 seated.");
            }
            default -> player.sendMessage("GTM Auto: /gtmrickshaw spawn | give | remove | status. Right-click auto to board; WASD drives, sneak exits.");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        List<String> options = sender.hasPermission("gtmrickshaw.admin")
                ? List.of("spawn", "give", "remove", "status") : List.of("status");
        return options.stream().filter(x -> x.startsWith(args[0].toLowerCase(java.util.Locale.ROOT)))
                .collect(Collectors.toList());
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.NORMAL)
    public void useToken(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!event.getAction().isRightClick()) return;
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!isToken(item)) return;
        event.setCancelled(true);
        if (spawnFor(player)) {
            if (item.getAmount() == 1) player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            else item.setAmount(item.getAmount() - 1);
        }
    }

    private boolean spawnFor(Player player) {
        if (rickshaws.size() >= maxVehicles) {
            player.sendMessage("Vehicle limit reached (" + maxVehicles + "). Ask the owner to remove an old pilot auto.");
            return false;
        }
        Location base = player.getLocation().clone();
        base.add(player.getLocation().getDirection().setY(0).normalize().multiply(3.2));
        base.setYaw(player.getLocation().getYaw());
        base.setPitch(0);
        if (!canOccupy(base, base.getYaw())) {
            player.sendMessage("Need a flat, clear, loaded road with room for the whole auto. No world blocks were changed.");
            return false;
        }
        Rickshaw car = null;
        try {
            car = create(base);
            rickshaws.put(car.id, car);
            player.sendMessage("Spawned real GTM auto model. Right-click body to board. Four seats available.");
            return true;
        } catch (RuntimeException failure) {
            if (car != null) remove(car);
            getLogger().warning("Could not create an auto: " + failure);
            player.sendMessage("Spawn failed; check server log. No item consumed.");
            return false;
        }
    }

    private Rickshaw create(Location base) {
        UUID id = UUID.randomUUID();
        List<Entity> spawned = new ArrayList<>();
        try {
            ItemDisplay display = base.getWorld().spawn(base, ItemDisplay.class, entity -> {
                entity.setItemStack(modelItem());
                entity.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                entity.setTransformation(new Transformation(
                    new Vector3f(0, 0.42f, 0), new AxisAngle4f(),
                    new Vector3f(1.45f, 1.45f, 1.45f), new AxisAngle4f()));
                entity.setTeleportDuration(2);
                entity.setPersistent(false);
                entity.setInvulnerable(true);
            });
            spawned.add(display);
            Interaction hitbox = base.getWorld().spawn(base, Interaction.class, entity -> {
                entity.setInteractionWidth(1.8f);
                entity.setInteractionHeight(2.1f);
                entity.setResponsive(true);
                entity.setPersistent(false);
            });
            spawned.add(hitbox);
            hitbox.getPersistentDataContainer().set(vehicleKey, PersistentDataType.STRING, id.toString());
            List<ArmorStand> seats = new ArrayList<>(4);
            for (int i = 0; i < 4; i++) {
                final int index = i;
                Location seatLocation = offset(base, base.getYaw(), SEAT_OFFSETS[i]);
                ArmorStand seat = base.getWorld().spawn(seatLocation, ArmorStand.class, stand -> {
                    stand.setInvisible(true);
                    stand.setMarker(true);
                    stand.setGravity(false);
                    stand.setInvulnerable(true);
                    stand.setCollidable(false);
                    stand.setSilent(true);
                    stand.setPersistent(false);
                    stand.getPersistentDataContainer().set(vehicleKey, PersistentDataType.STRING, id.toString());
                    stand.addScoreboardTag("gtm_seat_" + index);
                });
                seats.add(seat);
                spawned.add(seat);
            }
            Rickshaw car = new Rickshaw(id, base, display, hitbox, seats);
            sync(car);
            return car;
        } catch (RuntimeException ex) {
            for (Entity entity : spawned) if (entity.isValid()) entity.remove();
            throw ex;
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBoard(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (!(event.getRightClicked() instanceof Interaction hitbox)) return;
        String id = hitbox.getPersistentDataContainer().get(vehicleKey, PersistentDataType.STRING);
        if (id == null) return;
        event.setCancelled(true);
        Rickshaw car = null;
        try { car = rickshaws.get(UUID.fromString(id)); } catch (IllegalArgumentException ignored) {}
        if (car == null) return;
        Player player = event.getPlayer();
        if (player.isInsideVehicle()) {
            player.sendMessage("Exit your current seat before boarding another vehicle.");
            return;
        }
        for (int i = 0; i < car.seats.size(); i++) {
            ArmorStand seat = car.seats.get(i);
            if (!seat.isValid()) continue;
            if (seat.getPassengers().isEmpty() && seat.addPassenger(player)) {
                player.sendMessage(i == 0 ? "Driving: W accelerate, S brake/reverse, A/D steer, sneak exits."
                    : "Passenger seat " + i + "/3. Sneak to exit.");
                if (i == 0) player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.35f, 0.75f);
                return;
            }
        }
        player.sendMessage("Auto full: one driver and three passengers only.");
    }

    @EventHandler(ignoreCancelled = true)
    public void preventVehicleDamage(EntityDamageEvent event) {
        if (event.getEntity().getPersistentDataContainer().has(vehicleKey, PersistentDataType.STRING))
            event.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        for (Rickshaw car : rickshaws.values()) {
            for (ArmorStand seat : car.seats) if (seat.getPassengers().contains(player)) seat.removePassenger(player);
        }
    }

    private void tick() {
        ticks++;
        Iterator<Rickshaw> iterator = rickshaws.values().iterator();
        while (iterator.hasNext()) {
            Rickshaw car = iterator.next();
            if (!car.display.isValid() || !car.hitbox.isValid()
                    || car.seats.stream().anyMatch(seat -> !seat.isValid())) {
                remove(car); iterator.remove(); continue;
            }
            Player driver = car.seats.get(0).getPassengers().stream()
                    .filter(e -> e instanceof Player).map(e -> (Player) e).findFirst().orElse(null);
            if (driver == null) car.speed = 0;
            Input control = driver == null ? null : driver.getCurrentInput();
            RickshawPhysics.Input signals = control == null
                    ? new RickshawPhysics.Input(false, false, false, false)
                    : new RickshawPhysics.Input(control.isForward(), control.isBackward(),
                            control.isLeft(), control.isRight());
            RickshawPhysics.State after = RickshawPhysics.step(
                    new RickshawPhysics.State(car.speed, car.position.getYaw(),
                            car.position.getX(), car.position.getZ()), signals);
            Location next = car.position.clone();
            next.setX(after.x()); next.setZ(after.z()); next.setYaw((float) after.yaw());
            if (Math.abs(after.speed()) >= 0.001 && !canOccupy(next, after.yaw())) {
                car.speed = 0;
                if (driver != null && ticks % 10 == 0) driver.sendActionBar(Component.text("Brake: road blocked or unloaded", NamedTextColor.RED));
                continue;
            }
            boolean changed = Math.abs(next.getX()-car.position.getX()) > 0.0005
                    || Math.abs(next.getZ()-car.position.getZ()) > 0.0005
                    || Math.abs(next.getYaw()-car.position.getYaw()) > 0.0005;
            car.speed = after.speed();
            if (changed) {
                car.position = next;
                sync(car);
            }
            if (driver != null && ticks % 10 == 0) {
                driver.sendActionBar(Component.text("AUTO  " + Math.round(Math.abs(car.speed)*72)
                        + " km/h · " + occupied(car) + "/4 seats · W/A/S/D · Sneak exit", NamedTextColor.GOLD));
            }
        }
    }

    private boolean canOccupy(Location base, double yaw) {
        World world = base.getWorld();
        if (world == null) return false;
        for (double[] point : COLLISION_POINTS) {
            double x = base.getX() + RickshawPhysics.offsetX(point[0], point[1], yaw);
            double z = base.getZ() + RickshawPhysics.offsetZ(point[0], point[1], yaw);
            int cx = Math.floorDiv((int) Math.floor(x), 16);
            int cz = Math.floorDiv((int) Math.floor(z), 16);
            if (!world.isChunkLoaded(cx, cz)) return false; // NEVER generate distant chunks
            Block ground = world.getBlockAt((int)Math.floor(x), (int)Math.floor(base.getY()-0.15), (int)Math.floor(z));
            if (!ground.getType().isSolid() || ground.isLiquid()) return false;
            for (double height : new double[]{0.30, 1.24, 1.95}) {
                Block block = world.getBlockAt((int)Math.floor(x), (int)Math.floor(base.getY()+height), (int)Math.floor(z));
                if (block.getType().isSolid() || block.isLiquid()) return false;
            }
        }
        return true;
    }

    private Location offset(Location base, double yaw, double[] local) {
        Location loc = base.clone().add(
                RickshawPhysics.offsetX(local[0], local[2], yaw), local[1],
                RickshawPhysics.offsetZ(local[0], local[2], yaw));
        loc.setYaw((float) yaw);
        loc.setPitch(0);
        return loc;
    }

    private void sync(Rickshaw car) {
        Location pos = car.position;
        car.display.teleport(pos); // Paper 26.3 retains entity passengers by default
        car.hitbox.teleport(pos);
        for (int i = 0; i < car.seats.size(); i++) {
            car.seats.get(i).teleport(offset(pos, pos.getYaw(), SEAT_OFFSETS[i]));
        }
    }

    private Rickshaw nearest(Location location, double maxDistance) {
        Rickshaw candidate = null;
        double dist = maxDistance * maxDistance;
        for (Rickshaw car : rickshaws.values()) {
            if (car.position.getWorld() != location.getWorld()) continue;
            double d = car.position.distanceSquared(location);
            if (d < dist) { candidate = car; dist = d; }
        }
        return candidate;
    }

    private int occupied(Rickshaw car) {
        int count = 0;
        for (ArmorStand seat : car.seats) if (!seat.getPassengers().isEmpty()) count++;
        return count;
    }

    private void remove(Rickshaw car) {
        for (ArmorStand seat : car.seats) {
            for (Entity occupant : new ArrayList<>(seat.getPassengers())) seat.removePassenger(occupant);
            if (seat.isValid()) seat.remove();
        }
        if (car.hitbox.isValid()) car.hitbox.remove();
        if (car.display.isValid()) car.display.remove();
    }

    private static final class Rickshaw {
        private final UUID id;
        private Location position;
        private double speed;
        private final ItemDisplay display;
        private final Interaction hitbox;
        private final List<ArmorStand> seats;

        private Rickshaw(UUID id, Location position, ItemDisplay display,
                         Interaction hitbox, List<ArmorStand> seats) {
            this.id = id;
            this.position = position;
            this.display = display;
            this.hitbox = hitbox;
            this.seats = seats;
        }
    }
}
