package com.sdcraft.gtm.rickshaw;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RickshawPhysicsTest {
    @Test void accelerationBounded() {
        var s = new RickshawPhysics.State(0, 0, 0, 0);
        for (int i = 0; i < 500; i++) s = RickshawPhysics.step(s, new RickshawPhysics.Input(true, false, false, false));
        assertEquals(RickshawPhysics.MAX_FORWARD, s.speed(), 0.0000001);
        assertTrue(s.z() > 0);
    }

    @Test void brakeThenReverse() {
        var s = new RickshawPhysics.State(0.2, 0, 0, 0);
        for (int i = 0; i < 120; i++) s = RickshawPhysics.step(s, new RickshawPhysics.Input(false, true, false, false));
        assertEquals(RickshawPhysics.MAX_REVERSE, s.speed(), 0.0000001);
    }

    @Test void turningAndOffsets() {
        var s = RickshawPhysics.step(new RickshawPhysics.State(0.16, 0, 0, 0),
            new RickshawPhysics.Input(false, false, true, false));
        assertTrue(s.yaw() > 0);
        assertEquals(0, RickshawPhysics.offsetX(0, 0, 90), 0.00001);
        assertEquals(1, RickshawPhysics.offsetZ(1, 0, 90), 0.00001);
        assertEquals(-1, RickshawPhysics.offsetX(0, 1, 90), 0.00001);
    }

    @Test void idleEventuallyStops() {
        var s = new RickshawPhysics.State(0.15, 0, 0, 0);
        for (int i = 0; i < 200; i++) s = RickshawPhysics.step(s, new RickshawPhysics.Input(false, false, false, false));
        assertEquals(0, s.speed(), 0.0001);
    }
}
