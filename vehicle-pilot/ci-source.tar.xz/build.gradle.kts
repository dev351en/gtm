plugins {
    java
}

group = "com.sdcraft.gtm"
version = "0.1.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.3.build.258-stable")
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.4")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.test { useJUnitPlatform() }
tasks.jar {
    archiveBaseName.set("GTM-Vehicle-Pilot-Java26.3")
    manifest.attributes["Implementation-Title"] = "GTM Vehicle Pilot"
    manifest.attributes["Implementation-Version"] = project.version
}
