rootProject.name = "gtm-rickshaw-vehicle-pilot"
